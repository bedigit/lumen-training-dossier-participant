---
name: dg-context
description: Draws a context diagram as an editable draw.io file in the house style - the system in the centre, the people who use it on the left, the outside systems and organisations on the right, one labelled flow per exchange. Use it whenever someone asks for a context diagram, a system context, a "who and what talks to the system" picture, the actors and interfaces around a system or around one use case, or wants to see how a new feature or integration fits around the system, even when they do not say "draw.io". Not for sequence, activity or process diagrams, and not for data models.
---

# Context diagram in draw.io

A context diagram answers one question: who and what exchanges something with the system? It shows the system as a single box and never what happens inside it. An analyst uses it to agree on the boundary before talking about anything else, so a flow drawn by mistake is worse than a missing one.

You write one `.drawio` file. It opens in draw.io and stays editable. Nothing is installed and nothing is run: the file is text, and `template.drawio`, next to this file, gives you every piece to copy.

## Before you start

- The request gives the scope. It can be the whole system, one use case or domain ("UC-28", "banking"), or a change that is not built yet ("the Peppol integration") with a source that describes it, such as meeting notes. If there is no scope, draw the whole system.
- Read the rules of the working folder (`CLAUDE.md` or `AGENTS.md`) if there are any. They apply here.
- Read `template.drawio`. Copy its styles exactly: they are the house style.

## Steps

1. **Find the sources.** Start from the index of the documentation, then read only the pages that describe interfaces, roles or actors, and scope. For the whole system these pages are enough: do not open the use cases one by one. For one use case, read that use case and the interface pages it names. For a change, read the source that describes it and the pages of what it touches. Open all the pages you need in a single step, side by side: reading them one after the other makes the user wait several times longer for the same result.
2. **List the elements.** Three kinds only:
   - the *system*, once;
   - *people*, on the left: the roles that use the system. Name the role, not the person who holds it today, because people change and roles stay;
   - *outside*, on the right: the systems and organisations the system exchanges data or documents with.
3. **List the flows**, each with the page that states it and a status:
   - *documented*: a current reference page states it;
   - *planned*: the page marks it as a target, a future release or "to be analysed", it is an open question, or it comes from a meeting and nobody with the authority has decided it;
   - written nowhere: leave it out, and name it in your reply as "not documented".

   One flow per element. Use two only when part of the exchange is documented and part is planned.
4. **Write the file** as `diagrams/context-<scope>.drawio` at the root of the working folder, following the layout below. Keep it out of the documentation folder: the diagram is a deliverable, not a documentation page, and a wiki that only takes Markdown should stay that way.
5. **Reply** in a few lines: the path of the file; the pages you used; what you looked for and found "not documented"; your doubts, three at most. Do not list the flows again: they are in the diagram, each with its source.

## Layout

The page is 1600 by 1000. Every position is fixed, so that nothing overlaps and two diagrams drawn a month apart look the same. Do not compute your own.

| Element | x | width | height | y |
|---|---|---|---|---|
| System | 660 | 280 | 660 | 130 |
| People, left column | 60 | 220 | 70 | from the table below |
| Outside, right column | 1320 | 220 | 70 | from the table below |

Count the elements of a column, take that row, and give each element its `y` and its connector the `entryY` next to it:

| In the column | y / entryY of each element, top to bottom |
|---|---|
| 1 | 425 / 0.5 |
| 2 | 260 / 0.25 · 590 / 0.75 |
| 3 | 205 / 0.167 · 425 / 0.5 · 645 / 0.833 |
| 4 | 178 / 0.125 · 342 / 0.375 · 508 / 0.625 · 672 / 0.875 |
| 5 | 161 / 0.1 · 293 / 0.3 · 425 / 0.5 · 557 / 0.7 · 689 / 0.9 |
| 6 | 150 / 0.083 · 260 / 0.25 · 370 / 0.417 · 480 / 0.583 · 590 / 0.75 · 700 / 0.917 |

With these values every connector is a horizontal line.

More than six in a column: nobody reads that diagram. Keep the six that exchange the most and name the others in your reply.

**Connectors.** Each one goes from the element (`source`) to the system (`target="sys"`), whatever the direction of the exchange. Copy the matching sample of the template:

| Case | Sample to copy | What to set |
|---|---|---|
| One flow for the element | `f-role-a` on the left, `f-system-a` on the right | `exitY=0.5`, `entryY` from the table |
| Two flows for the element | `f-role-b-1` and `f-role-b-2` | `exitY=0.28` and `0.72`; `entryY` from the table minus 0.023 and plus 0.023; keep the two label offsets, they put one label above its line and the other below |
| Direction | | The system receives: `endArrow=block;startArrow=none`. The system sends: `endArrow=none;startArrow=block`. Both ways: both `block` |
| Planned or not confirmed | `f-new`, `f-role-b-2` | The dashed orange style |
| An element that does not exist yet | `x-new` | The orange box; for a role, keep the rounded shape of the people |

**Labels.** What is exchanged, then ` · ` and the short reference of the source, for example `· IF-04`. At most 60 characters before the source. Above 44 characters in all, cut the label into two lines of about the same length with a line break. Names take 24 characters at most and the small note under a name 30: they have to fit in the box.

## Rules

- **Language.** Write the diagram in English, unless the request is in another language or asks for one. Keep the names of systems, roles and identifiers exactly as the sources write them.
- **Nothing from outside the sources.** No element and no flow from general knowledge, even an obvious one. If the documentation does not say that customers receive invoices by email, the diagram does not say it either.
- **Only direct exchanges.** An exchange between two outside elements is not part of the context of this system.
- **No inside view.** No modules, databases or screens of the system.
- **The subtitle** gives the scope, the date of the sources if the folder states one, and the words "draft to review".
- **One file written.** Do not change the documentation. If the diagram shows a gap or a contradiction, say it in your reply.

## The draw.io file

- Keep the envelope of the template (`mxfile`, `diagram`, `mxGraphModel`, `root`, the cells `0` and `1`), the title, the subtitle and the legend. Replace the sample elements and connectors with yours.
- Every cell has a unique `id`. Use readable ones: `p-facturation`, `x-banklink`, `f-banklink-1`.
- Labels are HTML inside an XML attribute: write `&amp;` for &, `&lt;br&gt;` for a line break, `&quot;` for a quote. One unescaped `&` or `<` makes the whole file unreadable, so reread your labels before you save. Do not run any command, not even to check the file: nothing is needed, and a command would stop to ask the user for permission.
